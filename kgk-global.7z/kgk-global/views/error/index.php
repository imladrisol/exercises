<h1>Error</h1>
<?php echo $this->msg;?><br />
This is the error!