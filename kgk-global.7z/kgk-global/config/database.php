<?php

define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'kgk-global');
define('DB_USER', 'root');
define('DB_PASS', '');

