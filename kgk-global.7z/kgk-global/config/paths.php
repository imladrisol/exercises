<?php

define('URL', 'http://excersice/kgk-global/'); //change this before using!!
